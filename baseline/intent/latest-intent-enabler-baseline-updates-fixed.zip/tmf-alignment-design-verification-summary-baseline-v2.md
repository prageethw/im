# TMF Alignment Design Verification: Intent Enabler Architecture:

## Purpose:

This page verifies that the current **Intent Enabler** architecture aligns with the **TM Forum Intent Ontology (TIO)** and the TMF intent-management model.

## Executive summary:

The **Intent Enabler** acts as the **intent-handler-side platform**. It receives intent requirements from **OEX & Other Entities**, validates them, interprets them, applies network configuration, monitors assurance, and reports back using external `Intent` and `IntentReport` projections.

The external contract remains TMF-facing. Internal microservices, events, telemetry, optimisation, and knowledge processing are implementation details used to fulfil the intent.

II MS performs semantic validation and resolution using its lightweight internal KP together with the external `t7.knowledge plane` for network-related knowledge. This keeps the TMF-facing `Intent` contract clean while allowing the implementation to use richer network knowledge for fulfilment, assurance, and re-decision.

## TMF alignment table:

| Area | Our architecture | TMF alignment | Verification |
|---|---|---|---|
| Intent consumer | OEX & Other Entities | Intent owner side | Aligned |
| Intent handler | Intent Enabler | Intent handler side | Aligned |
| Intent resource | External `Intent` | Requirement object submitted to the autonomous domain | Aligned |
| Intent report | External `IntentReport` | Handler-to-owner reporting / control-loop feedback | Aligned |
| Intent specification | ID MS owns `IntentSpecification` | Rules for well-formed intent and allowed content | Aligned |
| TMF-facing lifecycle | IC MS owns external `Intent.lifecycleStatus` | External lifecycle/status projection | Aligned |
| Semantic interpretation | II MS uses lightweight internal KP and external `t7.knowledge plane` | Ontology/model-driven interpretation with network knowledge support | Aligned |
| Runtime assurance | IA MS produces assurance truth | Runtime compliance/assurance handling | Aligned |
| Callback support | ICB MS mediates incoming callbacks | Internal implementation support, not TMF-facing event exposure | Aligned |
| Optimisation | `t7.optimiser` | Internal fulfilment capability | Aligned |
| Orchestration | `t7.orchestrator` | Internal fulfilment/apply capability | Aligned |
| Telemetry | `t7.telemetry` | Runtime observation source for assurance | Aligned |

## Key design rules:

| Rule | Position |
|---|---|
| External contract | Keep TMF-facing through `Intent`, `IntentSpecification`, `IntentReport`, and TMF-style events |
| Internal events | Use for fulfilment and assurance; do not expose them as the external TMF contract |
| KP / knowledge plane | Keep lightweight II MS KP internal, and use external `t7.knowledge plane` for network-related knowledge; do not expose either as the external `Intent` or `IntentSpecification` |
| Lifecycle wording | Expose `lifecycleStatus`, `statusReason`, and `statusChangeDate`; do not expose raw internal state |
| IntentReport | Use as external assurance/reporting feedback |
| ICB MS | Incoming-only callback mediation; no client event exposure |
| Intent and report vocabulary | Keep coordinated so report-side projections exist for important intent-side concepts |

## Recommended stakeholder position:

| Layer | Position |
|---|---|
| External contract | TMF-facing |
| Internal fulfilment | Event-driven |
| Semantic resolution | Knowledge-driven |
| Runtime assurance | Telemetry-driven |
| External reporting | `Intent` lifecycle and `IntentReport` |

## Conclusion:

The architecture is aligned with TMF TIO when viewed as an **intent-handler-side implementation of an intent-enabled domain**.

The key governance rule is:

**Keep the TMF-facing contract clean and stable, while allowing the internal platform to use event-driven processing, knowledge-driven interpretation, optimisation, orchestration, callback mediation, and telemetry-driven assurance to fulfil the intent.**
